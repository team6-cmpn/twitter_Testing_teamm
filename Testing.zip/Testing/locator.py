from selenium.webdriver.common.by import By

class MainPageLocators(object):
    """A class for main page locators. All main page locators should come here"""

    SignUpGoogle = (By.CLASS_NAME, 'button')
    SignUpPhoneOrMail = (By.CSS_SELECTOR, '#root > div > div > div:nth-child(2) > div:nth-child(5) > div:nth-child(2) > a')
    SignIn = (By.CSS_SELECTOR, '#root > div > div > div:nth-child(2) > div:nth-child(5) > div:nth-child(5) > a')

class SignUpWithGooglePageLocators(object):

    "This class is for the sign in with google page"
    EnterEmail = (By.CSS_SELECTOR, '#identifierId')
    NextButton = (By.CSS_SELECTOR,'#identifierNext > div > button' )


class SignUpPhoneOrMailPageLocators(object):
    Name = (By.ID, "name")
    Username = (By.ID, "username")
    Email = (By.ID, "email")
    Password = (By.ID, "pass")
    Date = (By.CSS_SELECTOR, "#form1 > div:nth-child(7) > div > div > div > div > div > input")
    Next1 = (By.ID, "button")
    Next2 = (By.CSS_SELECTOR, 'body > div:nth-child(12) > div > div.ant-modal-wrap.ant-modal-centered > div > div.ant-modal-content > div.ant-modal-footer > button.ant-btn.ant-btn-round.ant-btn-primary.ant-btn-lg')
    SignUp = (By.CSS_SELECTOR, 'body > div:nth-child(14) > div > div.ant-modal-wrap.ant-modal-centered > div > div.ant-modal-content > div.ant-modal-footer > button.ant-btn.ant-btn-round.ant-btn-primary.ant-btn-lg')
    Next3 = (By.CSS_SELECTOR, 'body > div:nth-child(15) > div > div.ant-modal-wrap.ant-modal-centered > div > div.ant-modal-content > div.ant-modal-footer > button.ant-btn.ant-btn-round.ant-btn-primary.ant-btn-lg')


class SignInPageLocators(object):
    EmailOrUsername = (By.ID, "next")
    Next = (By.ID, "next1")
    #ForgetPassword = (By., "")
    #SignUp = (By., "")
    SignInGoogle = (By.CLASS_NAME, 'googleButton')
    Password = (By.ID, "password")
    ForgetPassword_2 = (By.ID, "forgetpassword")
    LogIn = (By.ID, "login")
    FindYourTwitterAccount = (By.CLASS_NAME, 'ant-input')
    Search = (By.CSS_SELECTOR, 'body > div:nth-child(8) > div > div.ant-modal-wrap.ant-modal-centered > div > div.ant-modal-content > div.ant-modal-footer > button.ant-btn.ant-btn-round.ant-btn-primary.ant-btn-lg')
    Next_2 = (By.CSS_SELECTOR, 'body > div:nth-child(9) > div > div.ant-modal-wrap.ant-modal-centered > div > div.ant-modal-content > div.ant-modal-footer > button.ant-btn.ant-btn-round.ant-btn-primary.ant-btn-lg')













    pass