from element import BasePageElement
from locator import MainPageLocators
from locator import SignUpWithGooglePageLocators
from locator import SignUpPhoneOrMailPageLocators
from locator import SignInPageLocators 


class BasePage(object):
    """Base class to initialize the base page that will be called from all
    pages"""

    def __init__(self, driver):
        self.driver = driver


#class TypeGoogleEmail(BasePageElement):
    #locator = "identifier"


class MainPage(BasePage):
    """Home page action methods come here. I.e. Python.org"""

    def click_SignUpWithGoogle_Button(self):
        """Triggers the search"""

        element = self.driver.find_element(*MainPageLocators.SignUpGoogle)
        element.click()

    def click_SignUpWithPhoneOrMail(self):
        """Triggers the search"""

        element = self.driver.find_element(*MainPageLocators.SignUpPhoneOrMail)
        element.click()

    def click_SignIn(self):
        """Triggers the search"""

        element = self.driver.find_element(*MainPageLocators.SignIn)
        element.click()


class EnterGoogleEmailPage(BasePage):

    def click_EnterEmail(self, str):

        element = self.driver.find_element(*SignUpWithGooglePageLocators.EnterEmail)
        element.send_keys(str)

    def click_Next(self):
        element= self.driver.find_element(*SignUpWithGooglePageLocators.NextButton) 
        element.click()   



class SignUpPhoneOrMailPage(BasePage):

    def enter_Name(self, str):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Name)
        element.send_keys(str)
    
    def enter_Username(self, str):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Username)
        element.send_keys(str)

    def enter_Email(self, str):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Email)
        element.send_keys(str)

    def enter_Password(self, str):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Password)
        element.send_keys(str)

    def enter_Date(self, str):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Date)
        element.send_keys(str)
    
    def click_Next_1(self):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Next1)
        element.click()

    def click_Next_2(self):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Next2)
        element.click()

    def SignUpButton(self):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.SignUp)
        element.click()

    def click_Next_3(self):
        element = self.driver.find_element(*SignUpPhoneOrMailPageLocators.Next3)
        element.click()


class SignInPage(BasePage):
    def enter_EmailOrUsername(self, str):
        element = self.driver.find_element(*SignInPageLocators.EmailOrUsername)
        element.send_keys(str)

    def click_Next(self):
        element = self.driver.find_element(*SignInPageLocators.Next)
        element.click()

    def click_ForgetPassword(self):
        element = self.driver.find_element(*SignInPageLocators.ForgetPassword)
        element.click()

    def click_SignUp(self):
        element = self.driver.find_element(*SignInPageLocators.SignUp)
        element.click()
    
    def click_SignInGoogle(self):
        element = self.driver.find_element(*SignInPageLocators.SignInGoogle)
        element.click()
    
    def enter_Password(self, str):
        element = self.driver.find_element(*SignInPageLocators.Password)
        element.send_keys(str)

    def click_ForgetPassword_2(self):
        element = self.driver.find_element(*SignInPageLocators.ForgetPassword_2)
        self.driver.implicitly_wait(100)
        element.click()

    def click_LogIn(self):
        element = self.driver.find_element(*SignInPageLocators.LogIn)
        element.click()

    def enter_EmailOrUsername_2(self,str):
        element = self.driver.find_element(*SignInPageLocators.FindYourTwitterAccount)
        element.send_keys(str)

    def click_Search(self):
        element = self.driver.find_element(*SignInPageLocators.Search)
        element.click()

    def click_next_2(self):
        element = self.driver.find_element(*SignInPageLocators.Next_2)
        element.click()



