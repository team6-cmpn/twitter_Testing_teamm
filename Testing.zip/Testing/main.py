import unittest
import page
from selenium import webdriver
from selenium.webdriver.chrome.service import Service



class TwitterHomePage(unittest.TestCase):
    """A sample test class to show how page object works"""

    def setUp(self):
        s = Service('C:\Program Files (x86)/chromedriver.exe')
        self.driver = webdriver.Chrome(service=s)
        #self.driver = webdriver.Chrome("C:\Program Files (x86)\chromedriver.exe")
        self.driver.get("http://localhost:3000/")
        self.driver.maximize_window()
        
        
    def test_SignUpWithGoogle(self):
        

        #Load the main page. In this case the home page of Python.org.
        main_page = page.MainPage(self.driver)
        #Clicks On Sign Up with google button
        (main_page.click_SignUpWithGoogle_Button(),'Button Didnt Press')
        self.driver.get("https://accounts.google.com/o/oauth2/auth/identifier?redirect_uri=storagerelay%3A%2F%2Fhttp%2Flocalhost%3A3000%3Fid%3Dauth877532&response_type=permission%20id_token&scope=email%20profile%20openid&openid.realm&include_granted_scopes=true&client_id=335712697506-0rdelma7j4jgcc6bicuhnn20e2l8m0fm.apps.googleusercontent.com&ss_domain=http%3A%2F%2Flocalhost%3A3000&prompt&fetch_basic_profile=true&gsiwebsdk=2&flowName=GeneralOAuthFlow")
        #self.driver.implicitly_wait(100)
        Enter_Google_Email_Page = page.EnterGoogleEmailPage(self.driver)
        (Enter_Google_Email_Page.click_EnterEmail("mohamed.k.elrafie@gmail.com"))
        self.assertFalse(Enter_Google_Email_Page.click_Next())

        
       
        
        
       

    def test_SignUpWithPhoneMail(self):
        
        
        #Load the main page. In this case the home page of Python.org.
        main_page = page.MainPage(self.driver)
        #Clicks On Sign Up with google button
        (main_page.click_SignUpWithPhoneOrMail(),'Button Didnt Press')
        signUpPhoneOrMail_Page = page.SignUpPhoneOrMailPage(self.driver)
        signUpPhoneOrMail_Page.enter_Username("@OmarGabr")
        signUpPhoneOrMail_Page.enter_Email("omargabr63@yahoo.com")
        signUpPhoneOrMail_Page.enter_Password("abcdefg123_")
        signUpPhoneOrMail_Page.enter_Date("2020-03-04")
        signUpPhoneOrMail_Page.enter_Name("Omar Gabr")
        signUpPhoneOrMail_Page.click_Next_1()
        signUpPhoneOrMail_Page.click_Next_2()
        self.driver.implicitly_wait(100)
        signUpPhoneOrMail_Page.SignUpButton()
        self.driver.implicitly_wait(100)
        self.assertFalse(signUpPhoneOrMail_Page.click_Next_3())

        
        

    def test_SignIn(self):
        

        #Load the main page. In this case the home page of Python.org.
        main_page = page.MainPage(self.driver)
        #Clicks On Sign Up with google button
        (main_page.click_SignIn(),'Button Didnt Press')
        signIn_Page = page.SignInPage(self.driver)
        signIn_Page.enter_EmailOrUsername("@OmarGabr")
        signIn_Page.click_Next()
        signIn_Page.enter_Password('abcdefg123_')
        signIn_Page.click_LogIn()

        

    def test_SignInGoogle(self):
        
        #Load the main page. In this case the home page of Python.org.
        main_page = page.MainPage(self.driver)
        #Clicks On Sign Up with google button
        (main_page.click_SignIn(),'Button Didnt Press')
        signIn_Page = page.SignInPage(self.driver)
        self.driver.implicitly_wait(100)
        signIn_Page.click_SignInGoogle()
        self.driver.get("https://accounts.google.com/o/oauth2/auth/identifier?redirect_uri=storagerelay%3A%2F%2Fhttp%2Flocalhost%3A3000%3Fid%3Dauth778568&response_type=permission%20id_token&scope=email%20profile%20openid&openid.realm&include_granted_scopes=true&client_id=335712697506-0rdelma7j4jgcc6bicuhnn20e2l8m0fm.apps.googleusercontent.com&ss_domain=http%3A%2F%2Flocalhost%3A3000&prompt&fetch_basic_profile=true&gsiwebsdk=2&flowName=GeneralOAuthFlow")
        Enter_Google_Email_Page = page.EnterGoogleEmailPage(self.driver)
        (Enter_Google_Email_Page.click_EnterEmail("mohamed.k.elrafie@gmail.com"))
        self.assertFalse(Enter_Google_Email_Page.click_Next())

        


    def test_SignIn_ForgetPassword2(self):
        main_page = page.MainPage(self.driver)
        #Clicks On Sign Up with google button
        main_page.click_SignIn(),'Button Didnt Press'
        signIn_Page = page.SignInPage(self.driver)
        signIn_Page.enter_EmailOrUsername("@OmarGabr")
        signIn_Page.click_Next()
        signIn_Page.click_ForgetPassword_2()
        self.driver.implicitly_wait(100)
        signIn_Page.enter_EmailOrUsername_2("@OmarGabr")
        signIn_Page.click_Search()
        self.assertFalse(signIn_Page.click_next_2())

        
        
        
   
    def tearDown(self):
        self.driver.close()

if __name__ == "__main__":
    unittest.main()





    










